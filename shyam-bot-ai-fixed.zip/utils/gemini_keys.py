# ╔══════════════════════════════════════════════════════════════════╗
# ║   Gemini API key rotation / failover manager                     ║
# ║   Drop this file in:  utils/gemini_keys.py                       ║
# ╚══════════════════════════════════════════════════════════════════╝
"""
Multi-key Gemini rotation.

Reads every Google/Gemini API key it can find and rotates through them:

  * round-robin  -> spreads load across all keys
  * cooldown     -> a key that returns 429 / quota-exceeded is parked for a
                    while instead of being hammered again
  * disable      -> a key that is invalid / revoked is dropped for the run
  * clear errors -> instead of a raw traceback the user sees something like
                    "⏳ All AI keys have reached their limit."

Supported .env layouts (all can be mixed):

    # one key per line
    GOOGLE_API_KEY=key1
    GOOGLE_API_KEY_2=key2
    GOOGLE_API_KEY_3=key3
    GEMINI_API_KEY=key4

    # or comma separated on a single line
    GOOGLE_API_KEY=key1,key2,key3

Because python-dotenv keeps only the LAST value of a repeated variable name,
this module also parses the raw .env file itself, so even this works:

    GOOGLE_API_KEY=key1
    GOOGLE_API_KEY=key2
    GOOGLE_API_KEY=key3
"""

from __future__ import annotations

import os
import re
import time
import asyncio
import logging
import threading

logger = logging.getLogger("discord")

# how long a key is parked after a rate-limit / quota error (seconds)
RATE_LIMIT_COOLDOWN = 60          # 429 "too many requests"
QUOTA_COOLDOWN = 60 * 30          # daily / per-minute quota exhausted
SERVER_ERROR_COOLDOWN = 15        # 500/503 from Google

_KEY_LINE = re.compile(
    r"^\s*(?:export\s+)?((?:GOOGLE|GEMINI)_API_KEY[A-Z0-9_]*)\s*[:=]\s*(.+?)\s*$"
)


# ────────────────────────────────────────────────────────────────────
#  Loading keys
# ────────────────────────────────────────────────────────────────────
def _split(raw: str):
    """Split a value that may hold several keys (comma / space / newline)."""
    if not raw:
        return []
    raw = raw.strip().strip('"').strip("'")
    parts = re.split(r"[,\n;\s]+", raw)
    out = []
    for p in parts:
        p = p.strip().strip('"').strip("'")
        if p and not p.lower().startswith("your_") and p != "KEY_HERE":
            out.append(p)
    return out


def _keys_from_env_file(path: str = ".env"):
    keys = []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                m = _KEY_LINE.match(line)
                if m:
                    keys.extend(_split(m.group(2)))
    except OSError:
        pass
    return keys


def load_keys():
    """Collect keys from the .env file, the environment and config.yml."""
    keys = []

    # 1. raw .env file (supports repeated GOOGLE_API_KEY lines)
    keys.extend(_keys_from_env_file(os.path.join(os.getcwd(), ".env")))

    # 2. environment variables: GOOGLE_API_KEY, GOOGLE_API_KEY_2, GEMINI_API_KEY...
    for name, value in os.environ.items():
        if re.fullmatch(r"(?:GOOGLE|GEMINI)_API_KEY[A-Z0-9_]*", name):
            keys.extend(_split(value))

    # 3. config.yml fallback
    try:
        from utils.config_loader import config  # local import: avoids cycles
        keys.extend(_split(str(config.get("GOOGLE_API_KEY") or "")))
        keys.extend(_split(str(config.get("GEMINI_API_KEY") or "")))
    except Exception:
        pass

    # de-duplicate, keep order
    seen, unique = set(), []
    for k in keys:
        if k not in seen:
            seen.add(k)
            unique.append(k)
    return unique


# ────────────────────────────────────────────────────────────────────
#  Error classification
# ────────────────────────────────────────────────────────────────────
def classify_error(exc: Exception) -> str:
    """Return one of: quota | rate_limit | invalid | model | safety |
    server | network | unknown"""
    msg = str(getattr(exc, "message", "") or exc).lower()
    status = getattr(exc, "status_code", None) or getattr(
        getattr(exc, "response", None), "status_code", None
    )
    if status is None:
        code = getattr(exc, "code", None)
        if isinstance(code, int):
            status = code
    name = type(exc).__name__.lower()

    if "resourceexhausted" in name or status == 429 or "quota" in msg or "rate limit" in msg:
        if "per day" in msg or "daily" in msg or "quota" in msg:
            return "quota"
        return "rate_limit"
    if (
        "permissiondenied" in name
        or "unauthenticated" in name
        or status in (401, 403)
        or "api key not valid" in msg
        or "api_key_invalid" in msg
        or "invalid api key" in msg
        or "expired" in msg
        or "suspended" in msg
    ):
        return "invalid"
    if (
        "notfound" in name
        or status == 404
        or "not found" in msg
        or "does not exist" in msg
        or "not have access" in msg
        or "model_not_found" in msg
        or "is not supported" in msg
    ):
        return "model"
    if "safety" in msg or "blocked" in msg or "recitation" in msg:
        return "safety"
    if (status is not None and 500 <= int(status) < 600) or "internal error" in msg or "unavailable" in msg or "overloaded" in msg:
        return "server"
    if "timeout" in msg or "timed out" in msg or "connection" in msg or "network" in msg or "ssl" in msg:
        return "network"
    return "unknown"


#: user-facing text for each failure reason
ERROR_MESSAGES = {
    "no_keys": (
        "🔑 **No AI key configured.**\n"
        "Ask the bot owner to add `GOOGLE_API_KEY=...` lines to the `.env` file "
        "(one key per line). Get free keys at https://aistudio.google.com/apikey"
    ),
    "quota": (
        "⏳ **AI limit reached.** All Gemini API keys have used up their daily "
        "quota. Please try again later, or add another key in `.env`."
    ),
    "rate_limit": (
        "🚦 **Too many requests.** Every AI key is rate limited right now. "
        "Give it a minute and try again."
    ),
    "invalid": (
        "🔑 **Invalid AI key.** Every configured Gemini key was rejected "
        "(invalid, revoked or expired). The bot owner needs to refresh the keys "
        "in `.env`."
    ),
    "model": (
        "🤖 **Model unavailable.** None of the configured Gemini models could be "
        "reached with these keys. Check `MODEL_ID` in `config.yml`."
    ),
    "safety": (
        "🛡️ **Blocked response.** The AI refused to answer that (safety filter). "
        "Try rephrasing your message."
    ),
    "server": (
        "🌐 **Google's AI servers are having issues** right now. Please try "
        "again in a moment."
    ),
    "network": (
        "📡 **Network error** while contacting the AI. Please try again."
    ),
    "unknown": (
        "⚠️ **The AI request failed.** Please try again in a moment."
    ),
}


def error_message(reason: str) -> str:
    return ERROR_MESSAGES.get(reason, ERROR_MESSAGES["unknown"])


class GeminiError(Exception):
    """Raised when every key/model combination failed."""

    def __init__(self, reason: str, original: Exception | None = None):
        self.reason = reason
        self.original = original
        super().__init__(error_message(reason))

    @property
    def user_message(self) -> str:
        return error_message(self.reason)


# ────────────────────────────────────────────────────────────────────
#  The rotator
# ────────────────────────────────────────────────────────────────────
class GeminiKeyManager:
    def __init__(self):
        self._lock = threading.Lock()
        self.keys = load_keys()
        self._index = 0
        self._cooldown = {}   # key -> timestamp until usable
        self._disabled = set()
        self.usage = {}       # key -> successful call count
        if self.keys:
            logger.warning(f"[Gemini] Loaded {len(self.keys)} API key(s) for rotation.")
        else:
            logger.warning("[Gemini] No GOOGLE_API_KEY found — AI features disabled.")

    # -- info -------------------------------------------------------
    @property
    def has_keys(self) -> bool:
        return bool(self.keys)

    def reload(self):
        with self._lock:
            self.keys = load_keys()
            self._cooldown.clear()
            self._disabled.clear()
            self._index = 0
        return len(self.keys)

    def status(self):
        """Human readable status list, handy for an owner command."""
        now = time.time()
        rows = []
        for i, key in enumerate(self.keys, 1):
            tail = key[-4:] if len(key) > 4 else "????"
            if key in self._disabled:
                state = "❌ invalid"
            elif self._cooldown.get(key, 0) > now:
                state = f"⏳ cooling down {int(self._cooldown[key] - now)}s"
            else:
                state = "✅ ready"
            rows.append(f"`#{i}` ••••{tail} — {state} ({self.usage.get(key, 0)} calls)")
        return rows

    # -- rotation ---------------------------------------------------
    def available_keys(self):
        now = time.time()
        with self._lock:
            live = [
                k for k in self.keys
                if k not in self._disabled and self._cooldown.get(k, 0) <= now
            ]
            if not live:
                return []
            start = self._index % len(live)
            self._index = (self._index + 1) % len(live)
        return live[start:] + live[:start]

    def mark_success(self, key):
        with self._lock:
            self.usage[key] = self.usage.get(key, 0) + 1
            self._cooldown.pop(key, None)

    def mark_failure(self, key, reason):
        with self._lock:
            if reason == "invalid":
                self._disabled.add(key)
                logger.warning(f"[Gemini] Key ••••{key[-4:]} disabled (invalid).")
            elif reason == "quota":
                self._cooldown[key] = time.time() + QUOTA_COOLDOWN
                logger.warning(f"[Gemini] Key ••••{key[-4:]} quota exhausted — rotating.")
            elif reason == "rate_limit":
                self._cooldown[key] = time.time() + RATE_LIMIT_COOLDOWN
                logger.warning(f"[Gemini] Key ••••{key[-4:]} rate limited — rotating.")
            elif reason == "server":
                self._cooldown[key] = time.time() + SERVER_ERROR_COOLDOWN

    # -- the workhorse ----------------------------------------------
    async def run(self, func, models=None):
        """Call ``func(key, model)`` (sync or async) rotating keys + models.

        ``func`` must perform ONE Gemini request. Raises :class:`GeminiError`
        when every combination failed.
        """
        if not self.has_keys:
            raise GeminiError("no_keys")

        keys = self.available_keys()
        if not keys:
            # everything is cooling down / disabled: report the strictest reason
            reason = "invalid" if len(self._disabled) == len(self.keys) else "quota"
            raise GeminiError(reason)

        models = models or [None]
        last_reason = "unknown"
        last_exc = None

        for key in keys:
            for model in models:
                try:
                    result = func(key, model) if model is not None else func(key)
                    if asyncio.iscoroutine(result):
                        result = await result
                    self.mark_success(key)
                    return result
                except GeminiError:
                    raise
                except Exception as e:      # noqa: BLE001 - classified below
                    last_exc = e
                    last_reason = classify_error(e)
                    logger.warning(
                        f"[Gemini] key ••••{key[-4:]} model={model} failed "
                        f"({last_reason}): {e}"
                    )
                    if last_reason == "model":
                        continue            # same key, next model
                    if last_reason == "safety":
                        raise GeminiError("safety", e)
                    self.mark_failure(key, last_reason)
                    break                   # next key
        raise GeminiError(last_reason, last_exc)


#: shared singleton used everywhere in the bot
key_manager = GeminiKeyManager()
