# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 CodeX Devs — All Rights Reserved              ║
# ║                                                                  ║
# ║   discord  ──  https://discord.gg/tFaGjmm7KR                      ║
# ║   youtube  ──  https://youtube.com/@CodeXDevs                   ║
# ║   github   ──  https://github.com/RayExo                        ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝

import aiohttp
import io
import time
import os
import random
import json
import asyncio
from types import SimpleNamespace
from langdetect import detect
from gtts import gTTS
from urllib.parse import quote
from utils.config_loader import load_current_language, config
try:
    from duckduckgo_search import AsyncDDGS
except ImportError:
    from ddgs import AsyncDDGS
from dotenv import load_dotenv
import google.generativeai as genai
from google.generativeai import types as genai_types

load_dotenv()

current_language = load_current_language()
internet_access = config.get('INTERNET_ACCESS', True)


from utils.gemini_keys import key_manager, GeminiError, error_message

# Gemini model rotation list - try in this order. If one is unavailable,
# doesn't exist, or you lack access, the bot moves to the next model.
GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-2.0-flash-lite",
    "gemini-1.5-flash",
    "gemini-1.5-pro",
]


class _Completion:
    """OpenAI-style response shape so existing callers
    (response.choices[0].message.content) keep working with Gemini."""

    def __init__(self, content):
        message = SimpleNamespace(content=content, tool_calls=None)
        choice = SimpleNamespace(message=message)
        self.choices = [choice]


def _to_gemini_contents(messages):
    """Convert OpenAI-style messages to Gemini contents + system instruction."""
    system_parts = []
    contents = []
    for msg in messages:
        role = msg.get("role", "user") if isinstance(msg, dict) else "user"
        content = msg.get("content", "") if isinstance(msg, dict) else str(msg)
        if not content:
            continue
        if role == "system":
            system_parts.append(content)
            continue
        contents.append({
            "role": "model" if role in ("assistant", "model") else "user",
            "parts": [{"text": content}],
        })
    system_instruction = "\n".join(system_parts) if system_parts else None
    return contents, system_instruction


async def chat_completion(model, messages, tools=None, **kwargs):
    """Send a chat completion to Google Gemini with KEY + MODEL ROTATION.

    - Every GOOGLE_API_KEY / GEMINI_API_KEY line in .env is loaded (one key per
      line, or comma separated) and rotated round-robin.
    - A key that is rate limited / out of quota is parked on a cooldown and the
      next key is used automatically; an invalid key is dropped.
    - Each key also walks the model rotation list when a model is unavailable.
    - If everything fails, a clear message is returned, e.g.
      "AI limit reached ..." instead of a crash.
    """
    generation_config = None
    if kwargs:
        generation_config = genai_types.GenerationConfig(
            temperature=kwargs.get("temperature"),
            max_output_tokens=kwargs.get("max_tokens"),
            top_p=kwargs.get("top_p"),
        )

    contents, system_instruction = _to_gemini_contents(messages)
    candidates = [model] + [m for m in GEMINI_MODELS if m != model] if model else list(GEMINI_MODELS)

    def _call(key, candidate):
        genai.configure(api_key=key)
        generative = genai.GenerativeModel(
            candidate,
            system_instruction=system_instruction,
        )
        response = generative.generate_content(
            contents,
            generation_config=generation_config,
        )
        text = getattr(response, "text", "") or ""
        if not text.strip():
            raise RuntimeError("Empty response from model")
        return _Completion(text.strip())

    async def _threaded(key, candidate):
        return await asyncio.to_thread(_call, key, candidate)

    try:
        return await key_manager.run(_threaded, models=candidates)
    except GeminiError as e:
        # Never crash the bot - hand the user a readable reason.
        return _Completion(e.user_message)


async def ask_gemini(prompt, system=None, model=None, **kwargs):
    """Small helper: one-shot prompt -> text (with full key rotation)."""
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    from utils.config_loader import config as _cfg
    completion = await chat_completion(
        model=model or _cfg.get("MODEL_ID", "gemini-2.0-flash"),
        messages=messages,
        **kwargs,
    )
    return completion.choices[0].message.content


async def generate_response(instructions, history):
    if not key_manager.has_keys:
        return error_message("no_keys")

    messages = [
            {"role": "system", "name": "instructions", "content": instructions},
            *history,
        ]

    tools = [
        {
            "type": "function",
            "function": {
                "name": "searchtool",
                "description": "Searches the internet.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The query for search engine",
                        }
                    },
                    "required": ["query"],
                },
            },
        }
    ]
    response = await chat_completion(
        model=config['MODEL_ID'],
        messages=messages,
        tools=tools,
    )
    response_message = response.choices[0].message
    tool_calls = response_message.tool_calls

    if tool_calls:
        available_functions = {
            "searchtool": duckduckgotool,
        }
        messages.append(response_message)

        for tool_call in tool_calls:
            function_name = tool_call.function.name
            function_to_call = available_functions[function_name]
            function_args = json.loads(tool_call.function.arguments)
            function_response = await function_to_call(
                query=function_args.get("query")
            )
            messages.append(
                {
                    "tool_call_id": tool_call.id,
                    "role": "tool",
                    "name": function_name,
                    "content": function_response,
                }
            )
        second_response = await chat_completion(
            model=config['MODEL_ID'],
            messages=messages
        ) 
        return second_response.choices[0].message.content
    return response_message.content

async def duckduckgotool(query) -> str:
    if not config.get('INTERNET_ACCESS', True):
        return "internet access has been disabled by user"
    blob = ''
    results = await AsyncDDGS(proxy=None).text(query, max_results=6)
    try:
        for index, result in enumerate(results[:6]):  # Limiting to 6 results
            blob += f'[{index}] Title : {result["title"]}\nSnippet : {result["body"]}\n\n\n Provide a cohesive response base on provided Search results'
    except Exception as e:
        blob += f"Search error: {e}\n"
    return blob


async def poly_image_gen(session, prompt):
    seed = random.randint(1, 100000)
    image_url = f"https://image.pollinations.ai/prompt/{prompt}?seed={seed}"
    async with session.get(image_url) as response:
        image_data = await response.read()
        return io.BytesIO(image_data)

async def generate_image_prodia(prompt, model, sampler, seed, neg):
    print("\033[1;32m(Prodia) Creating image for :\033[0m", prompt)
    start_time = time.time()
    async def create_job(prompt, model, sampler, seed, neg):
        url = 'https://api.prodia.com/generate'
        params = {
            'new': 'true',
            'prompt': f'{quote(prompt)}',
            'model': model,
            'steps': '100',
            'cfg': '9.5',
            'seed': f'{seed}',
            'sampler': sampler,
            'upscale': 'True',
            'aspect_ratio': 'square'
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                data = await response.json()
                return data['job']

    job_id = await create_job(prompt, model, sampler, seed, neg)
    url = f'https://api.prodia.com/job/{job_id}'
    headers = {
        'authority': 'api.prodia.com',
        'accept': '*/*',
    }

    async with aiohttp.ClientSession() as session:
        while True:
            async with session.get(url, headers=headers) as response:
                json = await response.json()
                if json['status'] == 'succeeded':
                    async with session.get(f'https://images.prodia.xyz/{job_id}.png?download=1', headers=headers) as response:
                        content = await response.content.read()
                        img_file_obj = io.BytesIO(content)
                        duration = time.time() - start_time
                        print(f"\033[1;34m(Prodia) Finished image creation\n\033[0mJob id : {job_id}  Prompt : ", prompt, "in", duration, "seconds.")
                        return img_file_obj

async def text_to_speech(text):
    bytes_obj = io.BytesIO()
    detected_language = detect(text)
    tts = gTTS(text=text, lang=detected_language)
    tts.write_to_fp(bytes_obj)
    bytes_obj.seek(0)
    return bytes_obj