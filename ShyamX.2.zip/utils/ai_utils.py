# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 CodeX Devs — All Rights Reserved              ║
# ║                                                                  ║
# ║   discord  ──  https://discord.gg/tFaGjmm7KR                      ║
# ║   youtube  ──  https://youtube.com/@CodeXDevs                   ║
# ║   github   ──  https://github.com/RayExo                        ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝

import aiohttp
import io
import time
import os
import random
import json
import asyncio
from types import SimpleNamespace
from langdetect import detect
from gtts import gTTS
from urllib.parse import quote
from utils.config_loader import load_current_language, config
try:
    from duckduckgo_search import AsyncDDGS
except ImportError:
    from ddgs import AsyncDDGS
from dotenv import load_dotenv
import google.generativeai as genai
from google.generativeai import types as genai_types

load_dotenv()

current_language = load_current_language()
internet_access = config.get('INTERNET_ACCESS', True)


def _get_gemini_keys():
    """Return the list of Google AI API keys from .env or config.yml."""
    raw = os.getenv("GOOGLE_API_KEY") or config.get("GOOGLE_API_KEY") or ""
    return [key.strip() for key in raw.split(",") if key.strip()]


GEMINI_KEYS = _get_gemini_keys()

# Gemini model rotation list — try in this order. If one is unavailable,
# doesn't exist, or you lack access, the bot moves to the next.
GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-1.5-flash",
    "gemini-1.5-pro",
]


def _model_error(e):
    """True if the error means the model is unavailable / no access."""
    try:
        from google.api_core.exceptions import NotFound, PermissionDenied
        if isinstance(e, (NotFound, PermissionDenied)):
            return True
    except ImportError:
        pass
    status = getattr(e, "status_code", None)
    if status is None:
        status = getattr(getattr(e, "response", None), "status_code", None)
    if status not in (400, 403, 404):
        return False
    msg = str(getattr(e, "message", "") or e)
    return (
        "not found" in msg
        or "does not exist" in msg
        or "model_not_found" in msg
        or "not have access" in msg
    )


class _Completion:
    """OpenAI-style response shape so existing callers
    (response.choices[0].message.content) keep working with Gemini."""

    def __init__(self, content):
        message = SimpleNamespace(content=content, tool_calls=None)
        choice = SimpleNamespace(message=message)
        self.choices = [choice]


def _to_gemini_contents(messages):
    """Convert OpenAI-style messages to Gemini contents + system instruction."""
    system_parts = []
    contents = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        if not content:
            continue
        if role == "system":
            system_parts.append(content)
            continue
        contents.append({
            "role": "model" if role == "assistant" else "user",
            "parts": [{"text": content}],
        })
    system_instruction = "\n".join(system_parts) if system_parts else None
    return contents, system_instruction


async def chat_completion(model, messages, tools=None, **kwargs):
    """Send a chat completion to the Google Gemini API with a MODEL ROTATION
    system.

    - Reads GOOGLE_API_KEY from .env (or config.yml) — multiple keys are
      rotated on auth / rate-limit / server errors.
    - Tries the configured model first, then the rotation list.
    - On a model error (not found / no access) it automatically tries the
      next model in the list.
    - If every model in the rotation fails, returns
      'All AI models are currently down' instead of crashing the bot.
    """
    keys = GEMINI_KEYS or _get_gemini_keys()
    if not keys:
        raise RuntimeError("No GOOGLE API key configured")

    # Rotation order: configured model first, then the remaining rotation list.
    candidates = [model] + [m for m in GEMINI_MODELS if m != model]

    generation_config = None
    if kwargs:
        generation_config = genai_types.GenerationConfig(
            temperature=kwargs.get("temperature"),
            max_output_tokens=kwargs.get("max_tokens"),
            top_p=kwargs.get("top_p"),
        )

    for key in keys:
        genai.configure(api_key=key)
        for candidate in candidates:
            try:
                contents, system_instruction = _to_gemini_contents(messages)
                generative = genai.GenerativeModel(
                    candidate,
                    system_instruction=system_instruction,
                )
                response = await asyncio.to_thread(
                    generative.generate_content,
                    contents,
                    generation_config=generation_config,
                )
                text = getattr(response, "text", "") or ""
                return _Completion(text.strip())
            except Exception as e:
                if _model_error(e):
                    # This model is unavailable — try the next model.
                    continue
                # Other API errors (quota, network, etc.) — try the next key.
                break

    # Every model in the rotation failed — don't crash the bot.
    return _Completion("All AI models are currently down")


async def generate_response(instructions, history):
    if not (GEMINI_KEYS or _get_gemini_keys()):
        return "The AI API key is not configured. Ask the bot owner to set GOOGLE_API_KEY in .env or config.yml."

    messages = [
            {"role": "system", "name": "instructions", "content": instructions},
            *history,
        ]

    tools = [
        {
            "type": "function",
            "function": {
                "name": "searchtool",
                "description": "Searches the internet.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The query for search engine",
                        }
                    },
                    "required": ["query"],
                },
            },
        }
    ]
    response = await chat_completion(
        model=config['MODEL_ID'],
        messages=messages,
        tools=tools,
    )
    response_message = response.choices[0].message
    tool_calls = response_message.tool_calls

    if tool_calls:
        available_functions = {
            "searchtool": duckduckgotool,
        }
        messages.append(response_message)

        for tool_call in tool_calls:
            function_name = tool_call.function.name
            function_to_call = available_functions[function_name]
            function_args = json.loads(tool_call.function.arguments)
            function_response = await function_to_call(
                query=function_args.get("query")
            )
            messages.append(
                {
                    "tool_call_id": tool_call.id,
                    "role": "tool",
                    "name": function_name,
                    "content": function_response,
                }
            )
        second_response = await chat_completion(
            model=config['MODEL_ID'],
            messages=messages
        ) 
        return second_response.choices[0].message.content
    return response_message.content

async def duckduckgotool(query) -> str:
    if not config.get('INTERNET_ACCESS', True):
        return "internet access has been disabled by user"
    blob = ''
    results = await AsyncDDGS(proxy=None).text(query, max_results=6)
    try:
        for index, result in enumerate(results[:6]):  # Limiting to 6 results
            blob += f'[{index}] Title : {result["title"]}\nSnippet : {result["body"]}\n\n\n Provide a cohesive response base on provided Search results'
    except Exception as e:
        blob += f"Search error: {e}\n"
    return blob


async def poly_image_gen(session, prompt):
    seed = random.randint(1, 100000)
    image_url = f"https://image.pollinations.ai/prompt/{prompt}?seed={seed}"
    async with session.get(image_url) as response:
        image_data = await response.read()
        return io.BytesIO(image_data)

async def generate_image_prodia(prompt, model, sampler, seed, neg):
    print("\033[1;32m(Prodia) Creating image for :\033[0m", prompt)
    start_time = time.time()
    async def create_job(prompt, model, sampler, seed, neg):
        url = 'https://api.prodia.com/generate'
        params = {
            'new': 'true',
            'prompt': f'{quote(prompt)}',
            'model': model,
            'steps': '100',
            'cfg': '9.5',
            'seed': f'{seed}',
            'sampler': sampler,
            'upscale': 'True',
            'aspect_ratio': 'square'
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                data = await response.json()
                return data['job']

    job_id = await create_job(prompt, model, sampler, seed, neg)
    url = f'https://api.prodia.com/job/{job_id}'
    headers = {
        'authority': 'api.prodia.com',
        'accept': '*/*',
    }

    async with aiohttp.ClientSession() as session:
        while True:
            async with session.get(url, headers=headers) as response:
                json = await response.json()
                if json['status'] == 'succeeded':
                    async with session.get(f'https://images.prodia.xyz/{job_id}.png?download=1', headers=headers) as response:
                        content = await response.content.read()
                        img_file_obj = io.BytesIO(content)
                        duration = time.time() - start_time
                        print(f"\033[1;34m(Prodia) Finished image creation\n\033[0mJob id : {job_id}  Prompt : ", prompt, "in", duration, "seconds.")
                        return img_file_obj

async def text_to_speech(text):
    bytes_obj = io.BytesIO()
    detected_language = detect(text)
    tts = gTTS(text=text, lang=detected_language)
    tts.write_to_fp(bytes_obj)
    bytes_obj.seek(0)
    return bytes_obj